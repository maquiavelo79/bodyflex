<h2 id="clock" class="sectionHead">Experience</h2>

<!--EXPERIENCE-->
<ul id="jobs">
	<li>
		<div class="details">
			<h3>Current Company</h3>
			<h4>Overlord - City, State</h4>
			<h5>Jul 2008 - Present</h5>
		</div>
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut justo nibh, mattis sit amet consequat a, varius vitae metus. Proin pharetra sodales pellentesque.</p>
	</li>
	<li>
		<div class="details">
			<h3>Some Other Company</h3>
			<h4>Lead Front-End Developer - City, State</h4>
			<h5>Jan 2010 - Jan 2011</h5>
		</div>
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut justo nibh, mattis sit amet consequat a, varius vitae metus. Proin pharetra sodales pellentesque.</p>
	</li>
	<li>
		<div class="details">
			<h3>Another Company</h3>
			<h4>Creative Director - City, State</h4>
			<h5>Jun 2008 - Dec 2009</h5>
		</div>
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut justo nibh, mattis sit amet consequat a, varius vitae metus. Proin pharetra sodales pellentesque.</p>
	</li>
</ul><!--end jobs-->

<div class="clear"></div>