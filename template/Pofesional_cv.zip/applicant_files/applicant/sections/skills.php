<h2 id="tools" class="sectionHead">Skills</h2>

<ul id="skills">
	<!--////////////////////////////////////////////////////////////////////////////////////-->
	<!--Notice the class names indicate the % of your skills. i.e. s70 = 70%, s40 = 40% etc. -->
	<!--////////////////////////////////////////////////////////////////////////////////////-->
	<li id="skill1" class="s90"><span>WordPress Development</span></li>
	<li id="skill2" class="s70"><span>PHP</span></li>
	<li id="skill3" class="s100"><span>HTML + CSS</span></li>
	<li id="skill4" class="s100"><span>jQuery</span></li>
	<li id="skill5" class="s100"><span>Photoshop</span></li>
	<li id="skill6" class="s90"><span>SEO</span></li>
	<li id="skill7" class="s90"><span>User Interface Design</span></li>
	<li id="skill8" class="s80"><span>Marketing</span></li>
	<li id="skill9" class="s40"><span><del>Underwater Basket Weaving</del></span></li>
</ul><!--end skills-->

<div class="clear"></div>