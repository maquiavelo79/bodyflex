<h2 id="learn" class="sectionHead">Education</h2>

<!--EDUCATION-->
<ul id="schools">
	<li>
		<div class="details">
			<h3>University of State</h3>
			<h4>Degree Title - Concentration</h4>
			<h5>2005 - 2007</h5>
		</div>
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut justo nibh, mattis sit amet consequat a, varius vitae metus. Proin pharetra sodales pellentesque.</p>
	</li>
	<li>
		<div class="details">
			<h3>State University</h3>
			<h4>Degree Title - Concentration</h4>
			<h5>2001 - 2004</h5>
		</div>
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut justo nibh, mattis sit amet consequat a, varius vitae metus. Proin pharetra sodales pellentesque.</p>
	</li>
</ul><!--end schooling-->

<div class="clear"></div>