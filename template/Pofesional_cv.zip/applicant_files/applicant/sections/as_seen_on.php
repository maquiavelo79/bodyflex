<h2 id="eye" class="sectionHead">As Seen On</h2>

<ul id="seenOn">
	<li class="bwWrapper"><img src="images/logos/abduzeedo.jpg" alt="Abduzeedo" /></li> 
	<li class="bwWrapper"><img src="images/logos/logo.png" alt="Awwwards" /></li> 
	<li class="bwWrapper"><img src="images/logos/creattica.png" alt="Creattica" /></li> 
	<li class="bwWrapper"><img src="images/logos/css_mania.png" alt="CSS Mania" /></li> 
	<li class="bwWrapper"><img src="images/logos/designers_couch.png" alt="Designers Couch" /></li> 
	<li class="bwWrapper"><img src="images/logos/dribbble.png" alt="Dribbble" /></li> 
	<li class="bwWrapper"><img src="images/logos/design_shack.png" alt="Design Shack" /></li> 
	<li class="bwWrapper"><img src="images/logos/envato_notes.png" alt="Envato Notes" /></li> 
	<li class="bwWrapper"><img src="images/logos/qnt_gallery.png" alt="qnt gallery" /></li> 
	<li class="bwWrapper"><img src="images/logos/specky_boy.png" alt="specky boy" /></li> 
	<li class="bwWrapper"><img src="images/logos/themeforest.png" alt="ThemeForest" /></li> 
	<li class="bwWrapper"><img src="images/logos/unmatchedstyle.png" alt="unmatchedstyle" /></li> 
	<li class="bwWrapper"><img src="images/logos/webdepot.jpg" alt="Web Designer Depot" /></li> 
	<li class="bwWrapper"><img src="images/logos/webmag.jpg" alt="Web Designer mag" /></li> 
	<li class="bwWrapper"><img src="images/logos/wptv-logo.png" alt="WordPress TV" /></li>
</ul><!--end seenOn-->

<div class="clear"></div>