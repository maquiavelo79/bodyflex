RESOURCES:

Icons provided by brankic1979.com

Background patterns provided by subtlepatterns.com

Lightbox provided by no-margin-for-errors.com

Help file available here: http://themolitor.com/help/applicant