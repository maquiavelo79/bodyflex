<?php

    define('_template_path','template/default.php');

    define('_from_name','QuanticaLabs@gmail.com');
    define('_from_email','quanticalabs@gmail.com');

    define('_to_name','QuanticaLabs@gmail.com');
    define('_to_email','quanticalabs@gmail.com');

    define('_host','');
    define('_username','');
    define('_password','');

    define('_subject_email','Geneva: Contact from WWW');

    define('_msg_invalid_data_name','Please enter your name.');
    define('_msg_invalid_data_email','Please enter valid e-mail.');
    define('_msg_invalid_data_message','Please enter your message.');

    define('_def_data_name','Your Name');
    define('_def_data_email','Your E-mail Address');
    define('_def_data_message','Message');

    define('_msg_send_ok','Thank you for contact us.');
    define('_msg_send_error','Sorry, we can\'t send this message.');
    
?>
