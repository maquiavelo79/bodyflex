
    $('.fancybox-image').fancybox({});